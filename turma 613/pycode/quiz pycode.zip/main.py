import pygame

largura = 1600
altura = 900
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Exemplo de Telas com Botões")


# Carregamento das imagens
inicio = pygame.image.load("inicio.png")
login = pygame.image.load("login.png")
acerto = pygame.image.load("acerto.png")
erro = pygame.image.load("erro.png")
nivel_1 = pygame.image.load("nivel 1.png")
nivel_2 = pygame.image.load("nivel 2.png")
nivel_3 = pygame.image.load("nivel 3.png")
nivel_4 = pygame.image.load("nivel 4.png")
nivel_5 = pygame.image.load("nivel 5.png")
nivel_6 = pygame.image.load("nivel 6.png")
nivel_7 = pygame.image.load("nivel 7.png")
como_jogar_1 = pygame.image.load("nivel 7.png")
credito = pygame.image.load("criadores.png")
agradecimento = pygame.image.load("agradecimento.png")
sobre_1 = pygame.image.load("sobre.png")
instrutores = pygame.image.load("instrutores.png")
configuracao = pygame.image.load("configuração.png")
acampamento_1 = pygame.image.load("acampamento 1.png")
acampamento_2 = pygame.image.load("acampamento 2.png")
acampamento_3 = pygame.image.load("acampamento 3.png")
acampamento_4 = pygame.image.load("acampamento 4.png")
cafe_1 = pygame.image.load("cafe 1.png")
cafe_2 = pygame.image.load("cafe 2.png")
cafe_3 = pygame.image.load("cafe 3.png")
cafe_4 = pygame.image.load("cafe 4.png")
hospital_1 = pygame.image.load("hospital 1.png")
hospital_2 = pygame.image.load("hospital 2.png")
hospital_3 = pygame.image.load("hospital 3.png")
hospital_4 = pygame.image.load("hospital 4.png")
escola_1 = pygame.image.load("escola 1.png")
escola_2 = pygame.image.load("escola  2.png")
escola_3 = pygame.image.load("escola 3.png")
escola_4 = pygame.image.load("escola 4.png")
cinema_1 = pygame.image.load("cinema 1.png")
cinema_2 = pygame.image.load("cinema 2.png")
cinema_3 = pygame.image.load("cinema 3.png")
cinema_4 = pygame.image.load("cinema 4.png")
biblioteca_1 = pygame.image.load("biblioteca 1.png")
biblioteca_2 = pygame.image.load("biblioteca 2.png")
biblioteca_3 = pygame.image.load("biblioteca 3.png")
biblioteca_4 = pygame.image.load("biblioteca 4.png")
mercadinho_1 = pygame.image.load("mercado 1.png")
mercadinho_2 = pygame.image.load("mercado 2.png")
mercadinho_3 = pygame.image.load("mercado 3.png")
mercadinho_4 = pygame.image.load("mercado 4.png")
config_jogo = pygame.image.load("configuração jogo.png")
bloqueio_1 = pygame.image.load("bloqueio tela 2.png")
bloqueio_2 = pygame.image.load("bloqueio fase 3.png")
bloqueio_3 = pygame.image.load("bloqueio tela 4.png")
bloqueio_4 = pygame.image.load("bloqueio fase 5.png")
bloqueio_5 = pygame.image.load("bloqueio fase 7.png")
bloqueio_6 = pygame.image.load("bloqueio fase 7.png")
concluiu_1 = pygame.image.load("concluiu fase 1.png")
concluiu_2 = pygame.image.load("concluiu fase 2.png")
concluiu_3 = pygame.image.load("concluiu fase 4.png")
concluiu_4 = pygame.image.load("concluiu fase 4.png")
concluiu_5 = pygame.image.load("concluiu fase 5.png")
concluiu_6 = pygame.image.load("concluiu fase 6.png")
concluiu_7 = pygame.image.load("concluiu fase 7.png")
final = pygame.image.load("final.png")

BRANCO = (255, 255, 255)

def tela_5():
    global moedas
    botao = pygame.Rect(245, 375, 85, 90)
    botao1 = pygame.Rect(730, 380, 85, 85)
    botao2 = pygame.Rect(245, 520, 85, 85)
    botao3 = pygame.Rect(730, 520, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                #tela_7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                #tela_7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                #tela_7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas += 25
                #tela_6()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                tela_4()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(acampamento_1, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, BRANCO)
        tela.blit(text, (1350, 40))

        pygame.display.flip()

    pygame.quit()

def tela_4():
    global moedas
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_5()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito()

        tela.fill((150, 150, 150))
        tela.blit(configuracao, (0, 0))

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        pygame.display.flip()

    pygame.quit()

def sobre():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_4()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_1()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()

    pygame.quit()

def credito_1():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_4()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def como_jogar():
    botao = pygame.Rect(700, 680, 200, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_4()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela



        pygame.display.flip()

    pygame.quit()

tela_5()